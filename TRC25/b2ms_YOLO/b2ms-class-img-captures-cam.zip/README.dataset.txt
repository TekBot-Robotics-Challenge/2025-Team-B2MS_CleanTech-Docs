# b2ms-class-img+capture > images+captures+recadrages
https://universe.roboflow.com/dataset-ik4if/b2ms-class-img-capture-ye5qo

Provided by a Roboflow user
License: CC BY 4.0

