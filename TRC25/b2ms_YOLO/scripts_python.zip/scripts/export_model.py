import os
from ultralytics import YOLO
from pathlib import Path
import argparse
import sys
import torch

# Définition des arguments
parser = argparse.ArgumentParser(description="Export du modèle YOLOv8 sous différents formats")
parser.add_argument('--model_path', help='Chemin du modèle à exporter (exemple : "runs/detect/train/weights/best.pt")',
                    default=r"runs/detect/train/weights/best.pt")
parser.add_argument('--export_to', help="Chemin du dossier d'export (exemple : 'models')",
                    default="models")
parser.add_argument('--name', help='Nom du modèle exporté (exemple : "my_model")',
                    default="my_model")
parser.add_argument('--imgsz', help='Taille des images pour l\'export', default=640)
args = parser.parse_args()

best_model_path = Path(args.model_path)
export_dir = Path(args.export_to)
model_name = args.name
imgsz = int(args.imgsz)

# Vérifications
if not best_model_path.exists():
    print(f"ERREUR : le modèle '{best_model_path}' est introuvable.")
    sys.exit(0)

export_dir.mkdir(exist_ok=True, parents=True)

# Chargement du modèle
print(f'Chargement du modèle : {best_model_path}')
model = YOLO(str(best_model_path))

# EXPORT 1 : ONNX
try:
    onnx_path = model.export(format='onnx', imgsz=640, optimize=True)
    print(f"Export ONNX réussi : {onnx_path}")
except Exception as e:
    print(f"Erreur export ONNX : {e}")

'''
# EXPORT 2 : TensorRT
try:
    trt_path = model.export(format='engine', imgsz=640, half=True)
    print(f"Export TensorRT réussi : {trt_path}")
except Exception as e:
    print(f"Export TensorRT non disponible sur cette machine : {e}")
'''

# EXPORT 3 : TorchScript 
try:
    torchscript_path = model.export(format='torchscript', imgsz=640, optimize=True)
    print(f"Export TorchScript réussi : {torchscript_path}")
except Exception as e:
    print(f"Erreur export TorchScript : {e}")

# EXPORT 4 : Modèle PyTorch (.pt)
pytorch_path = export_dir / f"{model_name}.pt"
model.save(str(pytorch_path))
print(f"Modèle PyTorch sauvegardé : {pytorch_path}")

# Résumé final
print("\nFormats exportés pour déploiement :")
print(f"- ONNX (.onnx)        : {onnx_path}")
print(f"- TorchScript (.torchscript) : {torchscript_path}")
print(f"- PyTorch (.pt)       : {pytorch_path}")
