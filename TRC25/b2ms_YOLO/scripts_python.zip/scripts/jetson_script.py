jetson_script = '''
import cv2
import numpy as np
from ultralytics import YOLO
import time

class WasteDetector:
    def __init__(self, model_path='models/b2ms_model.pt'):
        """
        Initialise le détecteur de déchets
        """
        self.model = YOLO(model_path)
        self.model.to('cuda')  # Utilisation du GPU Jetson

        # Classes pertinentes pour les déchets
        self.waste_classes = {
            0: 'dangereux',      
            1: 'menagers',         
            2: 'recyclables'
        }

    def detect_waste(self, image, conf_threshold=0.5):
        """
        Détecte les déchets dans une image
        """
        start_time = time.time()

        # Prédiction
        results = self.model(image, conf=conf_threshold, verbose=False)

        inference_time = time.time() - start_time

        # Extraction des détections
        detections = []
        if results[0].boxes is not None:
            for box in results[0].boxes:
                class_id = int(box.cls[0])
                if class_id in self.waste_classes:
                    confidence = float(box.conf[0])
                    bbox = box.xyxy[0].cpu().numpy()  # x1, y1, x2, y2

                    detection = {
                        'class_id': class_id,
                        'class_name': self.waste_classes[class_id],
                        'confidence': confidence,
                        'bbox': bbox,
                        'center': ((bbox[0] + bbox[2]) / 2, (bbox[1] + bbox[3]) / 2)
                    }
                    detections.append(detection)

        return detections, inference_time

    def draw_detections(self, image, detections):
        """
        Dessine les détections sur l'image
        """
        colors = {
            'Dangereux': (0, 0, 255)      # Rouge
            'Ménager': (0, 255, 255),     # Jaune
            'Recyclable': (0, 255, 0),    # Vert
        }

        for det in detections:
            bbox = det['bbox'].astype(int)
            color = colors.get(det['class_name'], (255, 255, 255))

            # Rectangle
            cv2.rectangle(image, (bbox[0], bbox[1]), (bbox[2], bbox[3]), color, 2)

            # Texte
            label = f"{det['class_name']} {det['confidence']:.2f}"
            cv2.putText(image, label, (bbox[0], bbox[1]-10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

        return image

# Exemple d'utilisation
def main():
    # Initialisation
    detector = WasteDetector('models/b2ms_model.pt')

    # Test avec webcam
    cap = cv2.VideoCapture(0)  # Caméra par défaut

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Détection
        detections, inference_time = detector.detect_waste(frame)

        # Affichage
        annotated_frame = detector.draw_detections(frame.copy(), detections)

        # Informations
        cv2.putText(annotated_frame, f"FPS: {1/inference_time:.1f}",
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        cv2.putText(annotated_frame, f"Objets: {len(detections)}",
                   (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

        cv2.imshow('Détection de déchets', annotated_frame)

        # Sortie avec 'q'
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
'''

# Sauvegarde du script
with open('jetson_waste_detector.py', 'w') as f:
    f.write(jetson_script)

print("✅ Script Jetson Nano créé : jetson_waste_detector.py")

# Script de démarrage rapide
startup_script = '''#!/bin/bash
# Script de démarrage pour Jetson Nano

echo "🤖 Démarrage du détecteur de déchets TEKBOT..."

# Activation de l'environnement virtuel (si nécessaire)
# source venv/bin/activate

# Lancement du détecteur
python3 jetson_waste_detector.py
'''

with open('start_detector.sh', 'w') as f:
    f.write(startup_script)

print("Script de démarrage créé : start_detector.sh")
print("Commande : chmod +x start_detector.sh && ./start_detector.sh")