from pathlib import Path
import os
import sys
from ultralytics import YOLO
import argparse

# Arguments
parser = argparse.ArgumentParser(
    description="Evaluation des données de validation")
parser.add_argument('--model_path', help='Chemin du modèle (exemple : "runs/detect/train/weights/best.pt")',
                    default=r"runs/detect/train/weights/best.pt")
parser.add_argument('--imgsz', help='format imgsz', default="640")
args = parser.parse_args()

best_model_path = Path(args.model_path)
imgsz = int(args.imgsz)

if __name__ == '__main__':
    if not best_model_path.exists():
        print('ERREUR : le chemin du modèle est invalide ou le fichier est introuvable.')
        sys.exit(0)

    data_yaml = Path("data.yaml")
    if not data_yaml.exists():
        print("ERREUR : fichier data.yaml introuvable.")
        sys.exit(0)

    print(f'Chargement du modèle : {best_model_path}')
    model = YOLO(str(best_model_path))

    print("Évaluation du modèle...")
    val_results = model.val(data=str(data_yaml), imgsz=imgsz)

    precision = val_results.box.mp    # mean precision
    recall = val_results.box.mr    # mean recall
    f1_score = val_results.box.f1.mean()  # F1-score moyen sur toutes les classes
    map50 = val_results.box.map50
    map5095 = val_results.box.map

    # Latence (préprocess + inference + NMS)
    latency = sum(val_results.speed.values())

    # Affichage
    print("\n=== Résultats d'évaluation ===")
    print(f"Precision : {precision:.3f}")
    print(f"Recall    : {recall:.3f}")
    print(f"F1-score  : {f1_score:.3f}")
    print(f"mAP@0.5(Mean Average Precicion 0.5<IOU)   : {map50:.3f}")
    print(f"mAP@0.5:0.95(Mean Average Precicion 0.5<IOU<0.95) : {map5095:.3f}")
    print(f"Latence moyenne : {latency:.3f} ms/image")