from pathlib import Path
import os
import sys
from ultralytics import YOLO
import argparse

# Arguments
parser = argparse.ArgumentParser(
    description="Evaluation des données de validation")
parser.add_argument('--model_path', help='Chemin du modèle (exemple : "runs/detect/train/weights/best.pt")',
                    default=r"runs/detect/train/weights/best.pt")
parser.add_argument('--imgsz', help='format imgsz', default="640")
args = parser.parse_args()

best_model_path = Path(args.model_path)
imgsz = int(args.imgsz)

if __name__ == '__main__':
    if not best_model_path.exists():
        print('ERREUR : le chemin du modèle est invalide ou le fichier est introuvable.')
        sys.exit(0)

    data_yaml = Path("data.yaml")
    if not data_yaml.exists():
        print("ERREUR : fichier data.yaml introuvable.")
        sys.exit(0)

    print(f'Chargement du modèle : {best_model_path}')
    model = YOLO(str(best_model_path))

    print("Évaluation du modèle...")
    val_results = model.val(data=str(data_yaml), imgsz=imgsz)

    res = val_results[0] if isinstance(val_results, list) else val_results

    print("\nRésultats globaux :")
    print(f"  mAP@0.5 : {res.box.map50:.3f}")
    print(f"  mAP@0.5:0.95 : {res.box.map:.3f}")
    print(f"  Précision : {res.box.mp:.3f}")
    print(f"  Rappel : {res.box.mr:.3f}")

    print(res)
