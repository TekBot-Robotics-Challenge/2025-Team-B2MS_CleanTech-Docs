# Chargement des résultats d'entraînement
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt
import argparse
import math

# DEFINITION DES ARGUMENTS D'ENTRÉE
parser = argparse.ArgumentParser(
    description="Visualisation des métriques YOLO")
parser.add_argument('--result_path', help='Chemin des resultats',
                    default=r"runs/detect/train/results.csv")
args = parser.parse_args()

# ANALYSE DES PARAMÈTRES UTILISATEUR
csv_path = Path(args.result_path)

if __name__ == '__main__':
    if csv_path.exists():
        # Lecture des métriques
        df = pd.read_csv(csv_path)
        df.columns = df.columns.str.strip()

        # Suppression des colonnes inutiles
        if 'epoch' not in df.columns:
            print(" Colonne 'epoch' introuvable. Vérifie ton fichier CSV.")
        else:
            metrics = [c for c in df.columns if c != 'epoch' and c !=
                       'time' and c != 'lr/pg0' and c != 'lr/pg1' and c != 'lr/pg2']

            n = len(metrics)
            cols = 5
            rows = math.ceil(n / cols)

            fig, axes = plt.subplots(rows, cols, figsize=(5 * cols, 4 * rows))
            axes = axes.flatten() if n > 1 else [axes]

            # Boucle sur chaque métrique
            for i, col in enumerate(metrics):
                axes[i].plot(df['epoch'], df[col], '-o', linewidth=2)
                axes[i].set_title(col, fontsize=10)
                axes[i].set_xlabel('epoch')
                axes[i].grid(True)

            # Si la grille a plus de cases que de métriques, on cache les cases vides
            for j in range(i + 1, len(axes)):
                axes[j].axis('off')

            plt.suptitle("Évolution des métriques YOLO", fontsize=14)
            plt.tight_layout(rect=[0, 0, 1, 0.97])
            plt.show()

            # MÉTRIQUES FINALES
            final_metrics = df.iloc[-1]
            print("\n=== MÉTRIQUES FINALES ===")
            for col in metrics:
                val = final_metrics[col]
                if pd.api.types.is_numeric_dtype(type(val)):
                    print(f"{col:30s} : {val:.4f}")
                else:
                    print(f"{col:30s} : {val}")

    else:
        print("Fichier de résultats non trouvé :", csv_path)
