import os
import sys
import argparse
import glob
import time

import cv2
import numpy as np
from ultralytics import YOLO


# DEFINITION DES ARGUMENTS D'ENTRÉE
parser = argparse.ArgumentParser(
    description="Programme de détection d'objets avec YOLO et caméra (image, dossier, vidéo, ou webcam.")

parser.add_argument('--model', help='Chemin du modèle (exemple : "runs/detect/train/weights/best.pt")',
                    required=True)
parser.add_argument('--source', help='Source de l''image : image ("test.jpg"), dossier ("test_dir"), vidéo ("testvid.mp4") ou index de caméra USB ("usb0")',
                    required=True)
parser.add_argument('--confidence', help='Seuil de confiance minimal pour afficher les objets détectés (exemple : "0.4")',
                    default=0.5)
parser.add_argument('--resolution', help='Résolution d''affichage au format LxH (exemple : "640x480"), \
                    sinon la résolution d''origine sera utilisée',
                    default=None)
args = parser.parse_args()

# ANALYSE DES PARAMÈTRES UTILISATEUR
model_path = args.model
img_source = args.source
min_thresh = float(args.confidence)
user_res = args.resolution
record = False

# CHARGEMENT DU MODÈLE
if not os.path.exists(model_path):
    print('ERREUR : le chemin du modèle est invalide ou le fichier est introuvable.')
    sys.exit(0)

print(f'Chargement du modèle : {model_path}')
model = YOLO(model_path, task='detect')
labels = model.names

# IDENTIFICATION DU TYPE DE SOURCE
img_ext_list = ['.jpg', '.jpeg', '.png']
vid_ext_list = ['.avi', '.mov', '.mp4']

if os.path.isdir(img_source):
    source_type = 'folder'
elif os.path.isfile(img_source):
    _, ext = os.path.splitext(img_source)
    if ext in img_ext_list:
        source_type = 'image'
    elif ext in vid_ext_list:
        source_type = 'video'
    else:
        print(f'Extension de fichier {ext} non supportée.')
        sys.exit(0)
elif 'usb' in img_source:
    source_type = 'usb'
    usb_idx = int(img_source[3:])
else:
    print(f'Source "{img_source}" invalide. Veuillez réessayer.')
    sys.exit(0)

# REGLAGE DE LA RÉSOLUTION
resize = False
if user_res:
    resize = True
    resW, resH = int(user_res.split('x')[0]), int(user_res.split('x')[1])
    print(f'Résolution choisie : {resW}x{resH}')

# CHARGEMENT DE LA SOURCE D’IMAGES
if source_type == 'image':
    imgs_list = [img_source]

elif source_type == 'folder':
    imgs_list = []
    for file in glob.glob(img_source + '/*'):
        _, file_ext = os.path.splitext(file)
        if file_ext in img_ext_list:
            imgs_list.append(file)
    print(f'{len(imgs_list)} images trouvées dans le dossier.')

elif source_type in ['video', 'usb']:
    cap_arg = img_source if source_type == 'video' else int(img_source[3:])
    cap = cv2.VideoCapture(cap_arg)
    if user_res:
        cap.set(3, resW)
        cap.set(4, resH)
    else:
        resW = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        resH = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        print(f'Résolution par défaut caméra : {resW}x{resH}')
    print(
        f'Source vidéo : {"caméra USB" if source_type == "usb" else "fichier vidéo"}')

# COULEURS DES BOÎTES DE DÉTECTION
bbox_colors = [(0, 0, 255), (0, 255, 255), (0, 255, 0)]

#  VARIABLES DE CONTRÔLE
avg_frame_rate = 0
frame_rate_buffer = []
fps_avg_len = 200
img_count = 0

# Dossiers de capture
img_dir = "captures/images"
vid_dir = "captures/videos"

# Création des dossiers s'ils n'existent pas
os.makedirs(img_dir, exist_ok=True)
os.makedirs(vid_dir, exist_ok=True)

print("Démarrage de la détection...\nAppuyez sur 'Q' pour quitter, 'P' pour pause, 'C' pour capturer une image, 'V': capture video, 'S': arret capture video.")

# BOUCLE PRINCIPALE D’INFERENCE
while True:
    t_start = time.perf_counter()

    # Chargement d'une image ou d'une frame
    if source_type in ['image', 'folder']:
        if img_count >= len(imgs_list):
            print('Toutes les images ont été traitées. Fin du programme.')
            sys.exit(0)
        img_filename = imgs_list[img_count]
        frame = cv2.imread(img_filename)
        img_count += 1

    elif source_type == 'video':
        ret, frame = cap.read()
        if not ret:
            print('Fin de la vidéo. Fin du programme.')
            break

    elif source_type == 'usb':
        ret, frame = cap.read()
        if (frame is None) or (not ret):
            print('Impossible de lire depuis la caméra USB')
            break

    # Redimensionnement
    if resize:
        frame = cv2.resize(frame, (resW, resH))

    # Détection YOLO
    results = model(frame, verbose=False)
    detections = results[0].boxes
    object_count = 0

    # Parcours des détections
    for det in detections:
        xyxy = det.xyxy.cpu().numpy().squeeze().astype(int)
        xmin, ymin, xmax, ymax = xyxy
        classidx = int(det.cls.item())
        classname = labels[classidx]
        conf = det.conf.item()

        if conf > min_thresh:
            color = bbox_colors[classidx % 3]
            cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), color, 2)
            label = f'{classname[1:len(classname)-1]}: {int(conf*100)}%'
            labelSize, baseLine = cv2.getTextSize(
                label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            label_ymin = max(ymin, labelSize[1] + 10)
            cv2.rectangle(frame, (xmin, label_ymin - labelSize[1] - 10),
                          (xmin + labelSize[0], label_ymin + baseLine - 10),
                          color, cv2.FILLED)
            cv2.putText(frame, label, (xmin, label_ymin - 7),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
            object_count += 1

    # Affichage FPS et comptage
    if source_type in ['video', 'usb']:
        cv2.putText(frame, f'FPS: {avg_frame_rate:0.2f}', (10, 20),
                    cv2.FONT_HERSHEY_SIMPLEX, .7, (0, 255, 255), 2)
    cv2.putText(frame, f'Detected objects: {object_count}', (10, 40),
                cv2.FONT_HERSHEY_SIMPLEX, .7, (0, 0, 0), 2)

    # Affichage à l’écran
    cv2.imshow(
        'Resultats YOLO  |  Q: quitter  |  P: pause  |  C: capturer  |  V: capture video  |  S: arret capture video', frame)

    # Gestion des touches clavier
    if source_type in ['image', 'folder']:
        key = cv2.waitKey()
    else:
        key = cv2.waitKey(5)

    if key in [ord('q'), ord('Q')]:
        break
    elif key in [ord('p'), ord('P')]:
        print('Pause : appuyez sur une touche pour continuer...')
        cv2.waitKey()
    elif key in [ord('c'), ord('C')]:
        img_cap = f"capture_{time.strftime('%Y%m%d_%H%M%S')}.png"
        img_path = os.path.join(img_dir, img_cap)
        cv2.imwrite(img_path, frame)
        print(f'Image enregistrée : {img_path}')

    elif key in [ord('v'), ord('V')] and (not record) and (source_type in ['video', 'usb']):
        record = True
        video_cap = f"video_{time.strftime('%Y%m%d_%H%M%S')}.avi"
        record_path = os.path.join(vid_dir, video_cap)
        record_fps = 30
        recorder = cv2.VideoWriter(record_path, cv2.VideoWriter_fourcc(
            *'MJPG'), record_fps, (resW, resH))
        print(f'Enregistrement video dans : {record_path}')

    if record:
        recorder.write(frame)
        if key in [ord('s'), ord('S')]:
            print(f'Video enregistrée : {record_path}')
            record=False
            recorder.release()

    # Calcul FPS
    t_stop = time.perf_counter()
    frame_rate_calc = float(1 / (t_stop - t_start))

    if len(frame_rate_buffer) >= fps_avg_len:
        frame_rate_buffer.pop(0)
    frame_rate_buffer.append(frame_rate_calc)
    avg_frame_rate = np.mean(frame_rate_buffer)

# FIN DE PROGRAMME
print(f'Fréquence moyenne : {avg_frame_rate:.2f} FPS')
if source_type in ['video', 'usb']:
    cap.release()
if record:
    recorder.release()
cv2.destroyAllWindows()
