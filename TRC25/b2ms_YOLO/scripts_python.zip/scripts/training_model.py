# Imports
import torch
from ultralytics import YOLO
import argparse

# DEFINITION DES ARGUMENTS D'ENTRÉE
parser = argparse.ArgumentParser(description="Entrainement du modèle YOLOv8")

parser.add_argument(
    '--model', help="Modèle de base pour l'entraînement (ex: yolov8n.pt)", default="yolov8n.pt")
parser.add_argument('--epochs', type=int, help="Nombre d'epochs", default=20)
parser.add_argument('--imgsz', type=int,
                    help="Taille des images d'entrée", default=640)
parser.add_argument('--batch', type=int, help="Taille du batch", default=16)

args = parser.parse_args()

# PARAMÈTRES
model_name = args.model
epochs = args.epochs
imgsz = args.imgsz
batch = args.batch

if __name__ == '__main__':
    # CHARGEMENT DU MODÈLE YOLO
    model = YOLO(model_name)

    train_config = {
        'data': 'data.yaml',
        'epochs': epochs,
        'imgsz': imgsz,
        'batch': batch,
        'device': 0 if torch.cuda.is_available() else 'cpu',
        'workers': 4,
        'project': 'runs/detect',
        'name': 'train',        # Nom de l'expérience
        'save_period': 5,       # Sauvegarde tous les 5 epochs
        'patience': 5,          # Early stopping
        'lr0': 0.01,           # Learning rate initial
        'warmup_epochs': 1,     # Epochs de warmup
        'verbose': True
    }

    print("Configuration d'entraînement :")
    for key, value in train_config.items():
        print(f"  {key}: {value}")

    # Entraînement du modèle
    print("Début de l'entraînement !")
    print("-" * 50)

    # Lancement de l'entraînement
    results = model.train(**train_config)

    print("Entraînement terminé !")
    print(f"Modèle sauvegardé dans : {results.save_dir}")
