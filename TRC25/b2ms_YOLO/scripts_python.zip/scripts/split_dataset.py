import yaml
from pathlib import Path
import random
import os
import sys
import shutil
from tqdm import tqdm
import argparse

# DEFINITION DES ARGUMENTS D'ENTRÉE
parser = argparse.ArgumentParser(
    description="Structure du data en train et valid")

parser.add_argument('--dataset_path', help='Chemin du dataset',
                    required=True)
parser.add_argument('--train_per', help='Pourcentage de train(entrainement), le reste pour la validation',
                    default=0.8)
args = parser.parse_args()

# ANALYSE DES PARAMÈTRES UTILISATEUR
data_path = args.dataset_path     # Chemin du dataset d'origine
train_percent = float(args.train_per)

# Vérification des paramètres
if not os.path.isdir(data_path):
    print("Le dossier spécifié par data_path est introuvable. Vérifie le chemin et réessaie.")
    sys.exit(0)

if train_percent < 0.01 or train_percent > 0.99:
    print("Valeur invalide pour train_percent. Elle doit être comprise entre 0.01 et 0.99.")
    sys.exit(0)

val_percent = 1 - train_percent


# Définition des chemins
# Dossier contenant les images originales
input_image_path = os.path.join(data_path, "images")
# Dossier contenant les labels
input_label_path = os.path.join(data_path, "labels")

cwd = os.getcwd()

# Dossiers de sortie
train_img_path = os.path.join(cwd, "data/train/images")
train_label_path = os.path.join(cwd, "data/train/labels")
val_img_path = os.path.join(cwd, "data/valid/images")
val_label_path = os.path.join(cwd, "data/valid/labels")


# Nettoyage et création des dossiers
for path in [train_img_path, train_label_path, val_img_path, val_label_path]:
    if os.path.exists(path):
        # Supprime les anciens fichiers pour éviter les doublons
        shutil.rmtree(path)
    os.makedirs(path)  # Crée les nouveaux dossiers vides
    print(f"Dossier prêt : {path}")


# Récupération des fichiers
img_file_list = [path for path in Path(
    input_image_path).rglob("*") if path.is_file()]
txt_file_list = [path for path in Path(
    input_label_path).rglob("*") if path.is_file()]

print(f"\nNombre total d'images : {len(img_file_list)}")
print(f"Nombre total de fichiers d'annotation : {len(txt_file_list)}")


# Détermination du nombre de fichiers à déplacer
file_num = len(img_file_list)
train_num = int(file_num * train_percent)
val_num = file_num - train_num

print(f"\nImages vers train : {train_num}")
print(f"Images vers valid : {val_num}")


# Mélange aléatoire des images
random.shuffle(img_file_list)
train_files = img_file_list[:train_num]
val_files = img_file_list[train_num:]

# Train
for img_path in tqdm(train_files, desc="Copie des fichiers train"):
    img_fn = img_path.name
    base_fn = img_path.stem
    txt_fn = base_fn + ".txt"
    txt_path = os.path.join(input_label_path, txt_fn)

    # Copie de l'image
    shutil.copy(img_path, os.path.join(train_img_path, img_fn))

    # Copie du label si disponible
    if os.path.exists(txt_path):
        shutil.copy(txt_path, os.path.join(train_label_path, txt_fn))

# Validation
for img_path in tqdm(val_files, desc="Copie des fichiers validation"):
    img_fn = img_path.name
    base_fn = img_path.stem
    txt_fn = base_fn + ".txt"
    txt_path = os.path.join(input_label_path, txt_fn)

    shutil.copy(img_path, os.path.join(val_img_path, img_fn))

    if os.path.exists(txt_path):
        shutil.copy(txt_path, os.path.join(val_label_path, txt_fn))


print("\nDivision du dataset terminée avec succès !")
print(f"Train : {len(os.listdir(train_img_path))} images")
print(f"Validation : {len(os.listdir(val_img_path))} images")
