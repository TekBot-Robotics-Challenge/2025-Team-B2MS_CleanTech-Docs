from smbus2 import SMBus
import time

ADDR = 0x15

bus = SMBus(1)

while True:
    try:
        bus.write_byte(ADDR, ord('A'))
        print("SENT: A")

        time.sleep(0.05)

        
        data = bus.read_i2c_block_data(ADDR, 0, 2)
	resp1 = bus.read_byte(ADDR)
	resp2 = bus.read_byte(ADDR)
	while(data == '' and resp1 =='' and resp2 ==''):
		data = bus.read_i2c_block_data(ADDR, 0, 2)
		resp1 = bus.read_byte(ADDR)
		resp2 = bus.read_byte(ADDR)

        print("RESPONSE:", ''.join(chr(x) for x in data))
	print("-----------------------")
	print("RESPONSE:", chr(resp1), chr(resp2))

    except Exception as e:
        print("ERROR:", e)

    time.sleep(1)
