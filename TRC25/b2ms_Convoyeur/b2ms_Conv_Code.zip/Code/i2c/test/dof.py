from smbus import SMBus
import time

SLAVE_ADDR = 0x15
bus = SMBus(1)

while True:
    try:
        # envoyer commande (un seul octet)
        bus.write_byte(SLAVE_ADDR, 0x01)
        # lire 2 octets de l'Arduino
        data = bus.read_i2c_block_data(SLAVE_ADDR, 0, 2)  # 2 octets
        high = data[0]
        low = data[1]
        print("Octets :", high, low)
        print("Réponse Arduino :", chr(high), chr(low))
    except Exception as e:
        print("Erreur I2C :", e)

    time.sleep(1)
