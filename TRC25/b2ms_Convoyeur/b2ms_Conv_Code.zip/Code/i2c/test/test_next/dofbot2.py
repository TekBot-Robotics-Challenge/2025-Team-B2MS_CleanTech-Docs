import smbus
import time

SLAVE_ADDR = 0x15

bus = smbus.SMBus(1)

while True:
    resp = bus.process_call(SLAVE_ADDR, 0x01, 42)

    high = (resp >> 8) & 0xFF
    low  = resp & 0xFF

    print("Réponse Arduino :", chr(high), chr(low))

    time.sleep(1)
