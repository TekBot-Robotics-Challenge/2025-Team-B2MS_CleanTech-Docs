from smbus import SMBus
import time

SLAVE_ADDR = 0x15
bus = SMBus(1)

while True:
        # process_call = write + read dans la même transaction
        resp = bus.process_call(SLAVE_ADDR, 0x01, 42)

        # resp est un entier 16 bits
        high = (resp >> 8) & 0xFF
        low  = resp & 0xFF

        print("Réponse brute :", resp)
        print("Réponse Arduino :", chr(high), chr(low))

        time.sleep(1)
