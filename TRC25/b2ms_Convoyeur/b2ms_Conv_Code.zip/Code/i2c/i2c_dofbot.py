import smbus
import time

# Bus I2C du Jetson
bus = smbus.SMBus(1)
ARDUINO_ADDR = 0x15


def send_command_and_read():
    try:
        #Envoyer une commande (ex: 5)
        bus.write_byte(ARDUINO_ADDR, 5)
        print("Commande envoyée: 5")

        #Lire la réponse de l'esclave (1 octet)
        time.sleep(1)  # petit délai pour que l'Arduino prépare la réponse
        resp = bus.read_byte(ARDUINO_ADDR)
        print("Réponse reçue de l'Arduino:", resp)
    except Exception as e:
        print("Erreur I2C:", e)


while True:
    send_command_and_read()
    time.sleep(1)  #boucle toutes les secondes
