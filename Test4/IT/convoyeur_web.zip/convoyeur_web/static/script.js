let hasInitialized = false;

// Gestion des onglets
const tabs = document.querySelectorAll('.tab-btn');
const sections = document.querySelectorAll('main section');

const DELAI_ANIM = 3000;

// Données système
let systemActif = false;
let totalCount = 0;
const counts = {red: 0, yellow: 0, blue: 0, green: 0, inconnu: 0};
const countElems = {
  red: document.getElementById('count-red'),
  yellow: document.getElementById('count-yellow'),
  blue: document.getElementById('count-blue'),
  green: document.getElementById('count-green')
};

const totalElem = document.getElementById('total-dechets');
const dernierDechetElem = document.getElementById('dernier-dechet');
const etatElem = document.getElementById('etat-systeme');

const detectedObjectElem = document.getElementById('detected-object');
const conveyorState = document.getElementById('pattern');

const history = [];
let currentLang = localStorage.getItem('lang') || 'fr';

const translations = {
  fr: {
    modeLabel: "Thème :",
    languageLabel: "Langue :",
    resetBtn: "Réinitialiser la base de données",
    exportBtn: "Exporter CSV",
    downloadChart: "Télécharger Graphique",
    exportStatsCsv: "Exporter Statistiques CSV",
    tubes: {
      red: "Dangereux",
      yellow: "Plastiques/Cartons",
      blue: "Recyclables",
      green: "Biodégradables",
      unknown: "Inconnu" 
    },
    tabs: ["Tableau de bord", "Historique", "Statistiques", "Paramètres"],
    title: "Système de Tri Intelligent - Convoyeur",
    unknown: "Inconnu",
    system: {
      state: "État",
      total: "Total déchets traités",
      taux: "Taux de detection",
      last: "Dernier déchet détecté",
      on: "Actif",
      off: "Inactif"
    }
  },
  en: {
    modeLabel: "Theme:",
    languageLabel: "Language:",
    resetBtn: "Reset Database",
    exportBtn: "Export CSV",
    downloadChart: "Download Chart",
    exportStatsCsv: "Export Stats CSV",
    tubes: {
      red: "Hazardous",
      yellow: "Plastics/Cartons",
      blue: "Recyclables",
      green: "Biodegradable",
      unknown: "Unknown"
    },
    tabs: ["Dashboard", "History", "Statistics", "Settings"],
    title: "Smart Sorting System - Conveyor",
    unknown: "Unknown",
    system: {
      state: "State",
      total: "Total Waste Processed",
      taux: "Detection rate",
      last: "Last Detected Waste",
      on: "Active",
      off: "Inactive"
    }
  }
};


function switchLang(lang) {
  currentLang = lang;
  localStorage.setItem('lang', lang);

  // Traduction onglets
  tabs.forEach((tab, idx) => {
    tab.textContent = translations[lang].tabs[idx];
  });

  // Traduction tubes
  document.querySelector('.tube.red div:nth-child(2)').textContent = translations[lang].tubes.red;
  document.querySelector('.tube.yellow div:nth-child(2)').textContent = translations[lang].tubes.yellow;
  document.querySelector('.tube.blue div:nth-child(2)').textContent = translations[lang].tubes.blue;
  document.querySelector('.tube.green div:nth-child(2)').textContent = translations[lang].tubes.green;

  // Autres traductions
  document.querySelector('.header-center h1').textContent = translations[lang].title;
  document.getElementById('resetCountersBtn').textContent = translations[lang].resetBtn;
  document.getElementById('exportBtn').textContent = translations[lang].exportBtn;
  document.getElementById('downloadChart').textContent = translations[lang].downloadChart;
  document.getElementById('exportStatsCsv').textContent = translations[lang].exportStatsCsv;
    
  // Labels mode et langue
  document.querySelector("#theme-switcher h1").textContent = translations[lang].modeLabel;
  document.querySelector("#language-switcher h1").textContent = translations[lang].languageLabel;

  // System info labels
  const systemLabels = document.querySelectorAll(".system-info p");

  if (systemLabels.length >= 4) {
    systemLabels[0].querySelector("strong").textContent = translations[lang].system.state + " :";
    systemLabels[1].querySelector("strong").textContent = translations[lang].system.total + " :";
    systemLabels[2].querySelector("strong").textContent = translations[lang].system.duration + " :";
    systemLabels[3].querySelector("strong").textContent = translations[lang].system.last + " :";
  }
  updateChart();  
  updateSystemState(systemActif ? "ON" : "OFF");
}

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');

    sections.forEach(s => s.classList.remove('active'));
    document.getElementById(tab.dataset.target).classList.add('active');
  });
});

// Thème
const lightThemeBtn = document.getElementById('lightThemeBtn');
const darkThemeBtn = document.getElementById('darkThemeBtn');

function applyTheme(theme) {
  if (theme === 'dark') {
    document.body.classList.add('dark-theme');
    darkThemeBtn.classList.add('active');
    lightThemeBtn.classList.remove('active');
  } else {
    document.body.classList.remove('dark-theme');
    lightThemeBtn.classList.add('active');
    darkThemeBtn.classList.remove('active');
  }
  localStorage.setItem('theme', theme);
}

lightThemeBtn.addEventListener('click', () => applyTheme('light'));
darkThemeBtn.addEventListener('click', () => applyTheme('dark'));

// Mise à jour état système
function updateSystemState(state) {
  const lang = localStorage.getItem('lang') || 'fr';
  const isOn = state === "ON";

  systemActif = isOn;
  etatElem.textContent = isOn
    ? "🟢 " + (lang === "fr" ? "Actif" : "Active")
    : "🔴 " + (lang === "fr" ? "Inactif" : "Inactive");
  etatElem.style.color = isOn ? "#27ae60" : "#e74c3c";
}


// Affichage le taux de detection du backend
function updateTaux(taux_) {
  document.getElementById('taux-detection').textContent = (taux_ ? taux_ : 0) + '%';
}


// Normalise couleurs backend (fr) vers frontend (en)
function normalizeColor(color) {
  const map = {
    rouge: 'red',
    jaune: 'yellow',
    bleu: 'blue',
    vert: 'green',
    inconnu: 'unknown'
  };
  return map[color] || color;
}

// Met à jour compteurs et affichages depuis données serveur
function updateCountsAndHistory(data) {
  // Remise à zéro compteurs locaux
  for (const c of Object.keys(counts)) {
    counts[c] = 0;
  }

  // Met à jour compteurs avec données normalisées
  for (const [colorFR, count] of Object.entries(data.compteurs)) {
    const colorEN = normalizeColor(colorFR);
    counts[colorEN] = count;
    if(countElems[colorEN]) countElems[colorEN].textContent = count;
  }

  totalCount = data.total || Object.values(counts).reduce((a,b) => a+b,0);
  totalElem.textContent = totalCount;

  if(data.dernier) {
    const dernierNorm = normalizeColor(data.dernier);
    dernierDechetElem.textContent = `${getTypeName(dernierNorm)}`;
  }

  // Mise à jour de l'historique local (prend les 20 derniers)
  if (Array.isArray(data.historique)) {
    history.length = 0; // vide
    // Normalise et ajoute
    data.historique.slice(-20).forEach(item => {
      history.push({
        time: item.time,
        type: normalizeColor(item.color || item.type),
        color: normalizeColor(item.color || item.type)
      });
    });
  }

  updateHistoryTable();
  updateChart();
}

// Récupère le nom traduit d’un type (couleur EN)
function getTypeName(type) {
  const tubes = translations[currentLang].tubes;
  return tubes[type] || translations[currentLang].unknown;
}

// Animation convoyeur
function conveyorAnimation(type) {
  detectedObjectElem.className = 'detected-object active';
  conveyorState.className = 'pattern moving';
  detectedObjectElem.style.backgroundColor = getTubeColor(type);
  setTimeout(() => {
    detectedObjectElem.className = 'detected-object';
    conveyorState.className = 'pattern';
    detectedObjectElem.style.backgroundColor = 'transparent';
  }, DELAI_ANIM);
}

// Couleurs tubes (frontend)
function getTubeColor(type) {
  switch (type) {
    case 'red': return '#ff4c4c';
    case 'yellow': return '#fbc02d';
    case 'blue': return '#1976d2';
    case 'green': return '#388e3c';
    default: return '#999';  //unknown
  }
}

// Met à jour le tableau historique HTML
function updateHistoryTable() {
  const tbody = document.getElementById('historyBody');
  tbody.innerHTML = '';
  history.slice().reverse().forEach(item => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${item.time}</td>
      <td>${getTypeName(item.type)}</td>
      <td><span style="display:inline-block;width:16px;height:16px;background-color:${getTubeColor(item.color)};border-radius:4px;"></span></td>
    `;
    tbody.appendChild(tr);
  });
}


// Export CSV historique
document.getElementById('exportBtn').addEventListener('click', () => {
  let csv = 'Chronologie,Type,Couleur\n';
  history.forEach(item => {
    csv += `"${item.time}","${getTypeName(item.type)}","${item.color}"\n`;
  });
  downloadFile(csv, 'historique_tri.csv');
});

// Export CSV stats
document.getElementById('exportStatsCsv').addEventListener('click', () => {
  let csv = 'Type,Quantité\n';
  for (const [type, count] of Object.entries(counts)) {
    csv += `"${getTypeName(type)}",${count}\n`;
  }
  downloadFile(csv, 'stats_tri.csv');
});

// Téléchargement CSV
function downloadFile(content, filename) {
  const blob = new Blob([content], {type: 'text/csv;charset=utf-8;'});
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Chart.js
let pieChart = null;

function initChart() {
  const ctx = document.getElementById('pieChart').getContext('2d');

  const labels = [
    translations[currentLang].tubes.red,
    translations[currentLang].tubes.yellow,
    translations[currentLang].tubes.blue,
    translations[currentLang].tubes.green,
    translations[currentLang].tubes.unknown
  ];

  pieChart = new Chart(ctx, {
    type: 'pie',
    data: {
      labels: labels,
      datasets: [{
        label: translations[currentLang].system.total,
        data: [0, 0, 0, 0, 0],
        backgroundColor: ['#ff4c4c', '#fbc02d', '#1976d2', '#388e3c', '#746f6f4c'],
        borderColor: '#fff',
        borderWidth: 2,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'bottom'
        },
        datalabels: {
          color: '#fff',
          font: {
            weight: 'bold'
          },
          formatter: (value, context) => {
            const total = context.chart.data.datasets[0].data.reduce((a, b) => a + b, 0);
            if (total === 0 || value === 0) return '';
            const percentage = (value / total) * 100;
            return percentage.toFixed(1) + '%';
          }
        }
      }
    },
    plugins: [ChartDataLabels]
  });
}


function updateChart() {
  if (!pieChart) return;

  pieChart.data.datasets[0].data = [
    counts.red,
    counts.yellow,
    counts.blue,
    counts.green,
    counts.unknown
  ];

  pieChart.data.labels = [
    translations[currentLang].tubes.red,
    translations[currentLang].tubes.yellow,
    translations[currentLang].tubes.blue,
    translations[currentLang].tubes.green,
    translations[currentLang].tubes.unknown
  ];

  pieChart.data.datasets[0].label = translations[currentLang].system.total;

  pieChart.update();
}



// Télécharger graphique en PNG
document.getElementById('downloadChart').addEventListener('click', () => {
  if (!pieChart) return;
  const link = document.createElement('a');
  link.download = 'graphique_tri.png';
  link.href = pieChart.toBase64Image();
  link.click();
});

// Boutons langues
document.getElementById('frBtn').addEventListener('click', () => {
  switchLang('fr');
  setActiveLangBtn('fr');
});
document.getElementById('enBtn').addEventListener('click', () => {
  switchLang('en');
  setActiveLangBtn('en');
});

function setActiveLangBtn(lang) {
  document.getElementById('frBtn').classList.toggle('active', lang === 'fr');
  document.getElementById('enBtn').classList.toggle('active', lang === 'en');
}

// Réinitialisation compteurs (appel API /reset)
document.getElementById('resetCountersBtn').addEventListener('click', () => {
  const code = prompt("Entrez le code secret (1234) pour réinitialiser :");
  if (!code) return;
  fetch('/reset', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ code_secret: code })
  }).then(res => {
    if (res.ok) {
      ancienTotal = 0;
      hasInitialized = true;
    } else {
      alert("Code secret incorrect !");
    }
  });
});

// Setup Socket.IO
const socket = io();

let ancienTotal = 0;

function setupSocketIO() {
  socket.on('update_data', (data) => {
    updateSystemState(data.etat_systeme);
    updateTaux(data.taux);
    updateCountsAndHistory(data);

    const couleurNorm = normalizeColor(data.dernier);
    const nouveauTotal = data.total;

    if (hasInitialized) {
      if (couleurNorm && nouveauTotal > ancienTotal) {
        ancienTotal = nouveauTotal;
        conveyorAnimation(couleurNorm);
      }
    } else {
      // Première initialisation : pas d'animation
      ancienTotal = nouveauTotal;
      hasInitialized = true;
    }
  });
}

// Initialisation complète
function init() {
  
  // Thème
  const savedTheme = localStorage.getItem('theme') || 'light';
  applyTheme(savedTheme);

  // Langue
  switchLang(currentLang);
  setActiveLangBtn(currentLang);

  // Onglets init (active premier)
  tabs[0].classList.add('active');
  sections.forEach((s, i) => s.classList.toggle('active', i === 0));

  // Chart
  initChart();

  // Socket
  setupSocketIO();
}

document.addEventListener('DOMContentLoaded', init);
