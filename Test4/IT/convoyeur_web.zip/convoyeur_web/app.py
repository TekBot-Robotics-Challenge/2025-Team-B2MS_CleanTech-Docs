from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO, emit
import serial
import threading
import time
from datetime import datetime

app = Flask(__name__)
app.secret_key = "tekbot2025"

# Configuration SocketIO
socketio = SocketIO(app,
                    cors_allowed_origins="*",
                    async_mode="threading",
                    logger=True,
                    engineio_logger=True)

# Données initiales
compteurs = {'Rouge': 0, 'Bleu': 0, 'Vert': 0, 'Jaune': 0, 'Inconnu': 0}
historique = []
derniers_dechets = {'entree': None, 'sortie': None}
totaux = {'entrees': 0, 'sorties': 0}
arduino = None
arduino_connected = False

# Connexion Arduino


def connect_arduino():
    global arduino, arduino_connected
    try:
        arduino = serial.Serial("COM3", 9600, timeout=1)
        arduino_connected = True
        print("Connexion Arduino réussie")
        socketio.emit('notification', {'message': 'Arduino connecté'})
    except Exception as e:
        print(f"Échec connexion Arduino: {e}")
        arduino_connected = False
        socketio.emit('notification', {
                      'message': f'Échec connexion Arduino: {e}'})

# Notification via WebSocket


def envoyer_notification(couleur, action):
    timestamp = datetime.now().strftime("%H:%M:%S")
    message = f"Déchet {couleur} {action} à {timestamp}"

    socketio.emit('notification', {
        'message': message,
        'couleur': couleur,
        'action': action,
        'timestamp': timestamp
    })

# Traduction des caractères vers des couleurs


def identifier_couleur(char):
    color_map = {'R': 'Rouge', 'G': 'Vert', 'B': 'Bleu', 'Y': 'Jaune'}
    return color_map.get(char.upper(), 'Inconnu')

# Historique


def enregistrer_historique(couleur, action):
    entry = {
        'couleur': couleur,
        'action': action,
        'timestamp': datetime.now().isoformat()
    }
    historique.append(entry)
    if len(historique) > 100:
        historique.pop(0)
    return entry

# Lecture Arduino en boucle


def lecture_arduino():
    while True:
        if arduino_connected and arduino.in_waiting:
            try:
                data = arduino.readline().decode().strip()
                if not data:
                    continue

                print(f"[Arduino] => {data}")

                if data in ['R', 'G', 'B', 'Y']:
                    couleur = identifier_couleur(data)
                    compteurs[couleur] += 1
                    derniers_dechets['sortie'] = derniers_dechets['entree']
                    totaux['entrees'] += 1
                    totaux['sorties'] = totaux['entrees'] - 1
                    derniers_dechets['entree'] = couleur

                    action = 'entrée'

                    # Historique + notification
                    entry = enregistrer_historique(couleur, action)
                    envoyer_notification(couleur, f"est {action}")

                    # Mise à jour via WebSocket
                    socketio.emit('update_data', {
                        'compteurs': compteurs,
                        'derniers': derniers_dechets,
                        'totaux': totaux,
                        'last_action': {
                            'type': action,
                            'couleur': couleur,
                            'timestamp': entry['timestamp']
                        },
                        'last_update': datetime.now().isoformat()
                    })

            except Exception as e:
                print(f"Erreur lecture Arduino: {e}")
                time.sleep(1)

        time.sleep(0.1)

# Routes Flask


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/status')
def status():
    return jsonify({
        'arduino_connected': arduino_connected,
        'last_update': datetime.now().isoformat()
    })


@app.route('/historique')
def get_historique():
    return jsonify(historique[-15:][::-1])


@app.route('/reset', methods=['POST'])
def reset():
    data = request.get_json()
    if data and data.get('code_secret') == '1234':
        for couleur in compteurs:
            compteurs[couleur] = 0
        historique.clear()
        derniers_dechets.update({'entree': None, 'sortie': None})
        totaux.update({'entrees': 0, 'sorties': 0})

        socketio.emit('update_data', {
            'compteurs': compteurs,
            'derniers': derniers_dechets,
            'totaux': totaux,
            'reset': True,
            'last_update': datetime.now().isoformat()
        })
        return '', 204
    return '', 403


@socketio.on('connect')
def handle_connect():
    emit('update_data', {
        'compteurs': compteurs,
        'derniers': derniers_dechets,
        'totaux': totaux,
        'last_update': datetime.now().isoformat()
    })


# Lancement de l’application
if __name__ == '__main__':
    connect_arduino()

    if arduino_connected:
        thread = threading.Thread(target=lecture_arduino)
        thread.daemon = True
        thread.start()

    socketio.run(app, host='0.0.0.0', port=5000,
                 debug=False, allow_unsafe_werkzeug=True)
