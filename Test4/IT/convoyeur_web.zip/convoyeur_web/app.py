from flask import Flask, render_template, jsonify, request
from flask_socketio import SocketIO, emit
import threading
import time
from datetime import datetime
import json, os
from collections import Counter
import serial.tools.list_ports

app = Flask(__name__)
app.secret_key = "tekbot2025"

# Configuration SocketIO
socketio = SocketIO(app,
                    cors_allowed_origins="*",
                    async_mode="threading",
                    logger=False,
                    engineio_logger=False)

# Chemins
DATA_FOLDER = "data"
HISTORIQUE_PATH = os.path.join(DATA_FOLDER, "historique.json")

# Variables globales
state = "OFF"
COLOR = ["rouge", "jaune", "bleu", "vert", "inconnu"]

COULEUR_TYPE = {
    "bleu": "recyclables",
    "jaune": "plastiques",
    "rouge": "dangereux",
    "vert": "organiques",
    "inconnu": "inconnu" 
}

# Initialisation dossier et fichier
if not os.path.exists(DATA_FOLDER):
    os.mkdir(DATA_FOLDER)
if not os.path.exists(HISTORIQUE_PATH):
    with open(HISTORIQUE_PATH, "w") as f:
        json.dump([], f)

# Chargement historique
try:
    with open(HISTORIQUE_PATH, "r") as f:
        historique = json.load(f)
except (json.JSONDecodeError, FileNotFoundError):
    historique = []
    with open(HISTORIQUE_PATH, "w") as f:
        json.dump(historique, f)

# Sauvegarde d’un déchet dans l’historique
def save_historique(couleur):
    type_dechet = COULEUR_TYPE.get(couleur.lower(), 'inconnu')
    entry = {
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "type": type_dechet,
        "color": couleur
    }
    historique.append(entry)
    with open(HISTORIQUE_PATH, "w", encoding="utf-8") as f:
        json.dump(historique, f, ensure_ascii=False, indent=2)
    return entry

# Génère les données à transmettre
def generer_data():
    counts = Counter(entry["color"] for entry in historique)
    compteurs = {c: counts.get(c, 0) for c in COLOR}    
    
    
    total = sum(compteurs.values())
    dernier = historique[-1]["color"] if historique else None

    # Calcul du taux : proportion des couleurs détectées différentes de "inconnu"
    inconnu_count = compteurs.get("inconnu", 0)
    detected_count = total - inconnu_count

    # taux = (detected_count/total)*100 if total > 0 else 0
    taux = round((detected_count / total) * 100, 2) if total > 0 else 0

    return {
        "compteurs": compteurs,
        "total": total,
        "taux": taux,
        "dernier": dernier,
        "historique": historique,
        "etat_systeme": state
    }
    
# Envoie les données via WebSocket
def broadcast_data():
    data = generer_data()
    socketio.emit("update_data", data)

@app.route('/')
def index():
    return render_template("index.html")

# Route pour lecture des données
@app.route('/data')
def get_data():
    data = generer_data()
    socketio.emit("update_data", data)
    return jsonify(data)

# Route pour ajouter un déchet
@app.route('/add', methods=["POST"])
def add_dechet():
    data = request.get_json()
    couleur = data.get("type")
    
    if couleur not in {"red", "yellow", "blue", "green", "inconnu"}:
        return jsonify({"error": "Type invalide"}), 400

    save_historique(couleur)
    broadcast_data()
    return jsonify({"success": True})

# Réinitialiser la base de données
@app.route('/reset', methods=["POST"])
def reset_data():
    historique.clear()
    with open(HISTORIQUE_PATH, "w") as f:
        json.dump([], f)
    broadcast_data()
    return jsonify({"success": True})

        
@socketio.on('connect')
def handle_connect():
    emit('update_data', generer_data())
    
arduino = None
arduino_connected = False
selected_port = None

def select_port():
    global selected_port
    ports = serial.tools.list_ports.comports()
    ports_list = [port.device for port in ports]
    
    if not ports_list:
        print("Aucun port détecté.")
        exit()
        
    print("Ports disponibles :")
    for port in ports:
        print(str(port))
            
    try:
        choice = int(input("Select Com Port for arduino: "))
        for i in range(len(ports_list)):
            if(ports_list[i].startswith("COM" + str(choice))):
                selected_port = "COM" + str(choice)
                print(f"Selected port: {selected_port}")
                break
        
        if selected_port is None:
            print("Port invalide.")
            exit()

    except ValueError:
        print("Entrée invalide.")
        exit()


def connect_arduino():
    select_port()
    global arduino, arduino_connected, selected_port
    
    try:
        arduino = serial.Serial(selected_port, 9600)
        arduino_connected = True
        print("Connexion Arduino réussie")
        socketio.emit('notification', {'message': 'Arduino connecté'})
        time.sleep(1)

        
    except Exception as e:
        print(f"Échec connexion Arduino: {e}")
        arduino_connected = False
        socketio.emit('notification', {
                      'message': f'Échec connexion Arduino: {e}'})


def lecture_arduino():
    while arduino_connected:
        if arduino.in_waiting:
            try:
                data = arduino.readline().decode().strip()
                if not data:
                    continue

                print(f"[Arduino] => {data}")

                if data in ['R', 'G', 'B', 'Y', 'U']:
                    mapping = {"R": "rouge", "Y": "jaune", "B": "bleu", "G": "vert", "U": "inconnu"} 
                    type_ = mapping[data]
                    save_historique(type_)
                    broadcast_data()
                
                elif data in ["ON", "OFF"]:
                    global state
                    state = data
                    broadcast_data()
                    

            except Exception as e:
                print(f"Erreur lecture Arduino: {e}")
                time.sleep(0.5)

        time.sleep(0.1)



# Lancement de l’application
if __name__ == '__main__':
    connect_arduino()

    if arduino_connected:
        thread = threading.Thread(target=lecture_arduino)
        thread.daemon = True
        thread.start()

    socketio.run(app, host='0.0.0.0', port=5000,
                 debug=False, allow_unsafe_werkzeug=True)
